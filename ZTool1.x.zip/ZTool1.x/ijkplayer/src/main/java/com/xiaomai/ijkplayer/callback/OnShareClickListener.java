package com.xiaomai.ijkplayer.callback;

/**
 * Created by XiaoMai on 2017/6/28.
 */

public interface OnShareClickListener {

    void onShareClick(String title, String url);
}
