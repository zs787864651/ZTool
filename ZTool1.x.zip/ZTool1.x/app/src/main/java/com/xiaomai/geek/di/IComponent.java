
package com.xiaomai.geek.di;

/**
 * Created by XiaoMai on 2017/3/29 17:37.
 */

public interface IComponent<C> {

    C getComponent();
}
