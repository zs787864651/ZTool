package com.xiaomai.geek.di.module;

import dagger.Module;

/**
 * Created by XiaoMai on 2017/3/30 16:35.
 */

@Module
public class PasswordModule {
}
