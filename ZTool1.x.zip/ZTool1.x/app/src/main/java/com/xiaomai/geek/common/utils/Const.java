package com.xiaomai.geek.common.utils;

/**
 * Created by XiaoMai on 2017/5/9.
 */

public class Const {

    public static final int PAGE_SIZE = 30;

}
