package com.xiaomai.geek.data.net.response

/**
 * Created by XiaoMai on 2017/6/1.
 */
class ContentResp(var content: String)