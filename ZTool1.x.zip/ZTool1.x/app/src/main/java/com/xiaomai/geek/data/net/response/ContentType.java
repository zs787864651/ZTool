
package com.xiaomai.geek.data.net.response;

/**
 * Created by XiaoMai on 2017/3/18 11:22.
 */

public enum ContentType {

    file, dir,
    // 符号链接
    symlink
}
