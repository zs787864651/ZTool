package com.xiaomai.geek.data.module

/**
 * Created by XiaoMai on 2017/6/3.
 */
class Issue{
    var title: String? = null
    var body: String? = null
    var assignees: Array<String>? = null
    var labels: Array<String>? = null
}
