package com.xiaomai.mvp;

/**
 * Created by XiaoMai on 2017/3/29 17:13.
 */

public interface MvpView {
}
